<?php

namespace App\Policies;

use App\Models\User;
use App\Models\census;
use Illuminate\Auth\Access\Response;
use Symfony\Component\HttpFoundation\Request;

class CensusPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, census $census): bool
    {
        return true;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, census $census): bool
    {
        return true;
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, census $census): bool
    {
        return true;
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, census $census): bool
    {
        return true;
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(User $user, census $census): bool
    {
        return true;
    }

    public function searchAddress(User $user, census $census, Request $request): bool
    {
        return true;
    }
}
