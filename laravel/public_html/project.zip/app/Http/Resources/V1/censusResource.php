<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class censusResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
        'id' => $this->id,
        'role_id' => $this->role_id,
        'firstname' => $this->firstname,
        'middlename' => $this->middlename,
        'lastname' => $this->lastname,
        'gender' => $this->gender,
        'address' => $this->address,
        'age' => $this->age,
        'birthdate' => $this->birthdate,
        'contactNumber' => $this->contactNumber,
        ];
    }
}
