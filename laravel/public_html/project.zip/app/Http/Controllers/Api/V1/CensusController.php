<?php

namespace App\Http\Controllers\Api\V1;

use App\filters\ApiFilter;
use App\filters\CensusFilter;
use App\Http\Controllers\Controller;
use App\Http\Requests\StorecensusRequest;
use App\Http\Requests\UpdatecensusRequest;
use App\Http\Resources\V1\censusCollection;
use App\Http\Resources\V1\censusResource;
use App\Models\census;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CensusController extends Controller
{
    /**
     * Display a listing of the resource.
     */

     public function __construct()
{
    $this->middleware(function ($request, $next) {
        Log::info('Request Headers: ' . json_encode($request->header()));

        return $next($request);
    });
}

    public function index(Request $request)
    {
        $this->authorize('view-any', census::class);
        $filter = new CensusFilter();
        $filterItem = $filter->transform($request);
        $census = census::where($filterItem);

        if (count($filterItem) == 0) {
            return new censusCollection(census::get()); // Use get() to retrieve all data without pagination
        } else {
            return new censusCollection(census::where($filterItem)->get()); // Use get() to retrieve filtered data without pagination
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorecensusRequest $request, census $census)
    {
        $this->authorize('create', census::class);
        // Create a new Census instance
        $census = new Census();

        // Validate the incoming request data
        $validated = $request->validated();
    
        // Set the attributes on the Census model
        $census->fill($validated);
    
        // Save the Census model to the database
        $census->save();
    
        // Return a response with the created Census resource
        return new CensusResource($census);
    }

    /**
     * Display the specified resource.
     */
    public function show(census $census)
    {
        $this->authorize('view', $census);
        return new CensusResource($census);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(census $census)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatecensusRequest $request, census $census)
    {
        $this->authorize('update', $census); // Authorize based on the specific $census record
        $validated = $request->validated();
    
        $census->update($validated);
        return new censusResource($census);
    }
    

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, Census $census)
    {
        $this->authorize('delete', $census);
        if (!$census) {
            return response()->json(['message' => 'Resident not found'], 404);
        }

        $census->delete();

        return response()->json(['message' => 'Resident deleted successfully']);
    }


    public function searchCensus(Request $request)
    {

        $this->validate($request, [
            'full_name' => 'required|string',
        ]);

        $fullName = $request->input('full_name');
        Log::info('Full Name: ' . $fullName);
    
        // Check if the comma delimiter exists in the $fullName string
        if (strpos($fullName, ',') !== false) {
            list($firstName, $lastName) = explode(',', $fullName);
    
            $user = Census::where([
                'firstname' => $firstName,
            ])->get();

            if (!empty($lastName)) {
                $user = Census::where(['lastname' => $lastName])->get();
            }
    
            if ($user) {
                // If user found in the census, return the user information
                return response()->json(['user' => $user]);
            } else {
                return response()->json(['message' => "User not found"], 404);
            }
        } else {
            return response()->json(['message' => "Invalid full name format"], 400);
        }
    }
    

    public function searchAddress(Request $request)
{
    $this->validate($request, [
        'input' => 'required|string',
    ]);
    $addressKeyword = $request->input('input');
    Log::info('Address Keyword: ' . $addressKeyword);

    $query = Census::where('address', 'LIKE', '%' . $addressKeyword . '%');
    $user = $query->get();

    // Debug: Log the generated SQL query
    Log::info('SQL Query: ' . $query->toSql());

    if ($user->isEmpty()) {
        return response()->json(['message' => "No users found with the specified address keyword"], 404);
    } else {
        return response()->json(['user' => $user]);
    }
}

}