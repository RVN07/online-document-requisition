<?php

namespace App\Http\Controllers\Api\V1;

use App\Models\census;
use App\Models\ChatbotInteraction;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreChatbotInteractionRequest;
use App\Http\Requests\UpdateChatbotInteractionRequest;
use App\Models\User;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
class ChatbotInteractionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreChatbotInteractionRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ChatbotInteraction $chatbotInteraction)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ChatbotInteraction $chatbotInteraction)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateChatbotInteractionRequest $request, ChatbotInteraction $chatbotInteraction)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ChatbotInteraction $chatbotInteraction)
    {
        //
    }

    
public function processMessage(Request $request)
{
    $this->validate($request, [
        'message' => 'required|string',
    ]);

    $message = $request->input('message');

    // Replace 'YOUR_ACCESS_TOKEN' with the actual Wit.ai access token
    $witAiAccessToken = 'XBPQPDRMD22SSBLAPNZAQTFXAIPXG24S';

    $httpClient = new Client();

    // Send user message to wit.ai for analysis
    $witResponse = $httpClient->get('https://api.wit.ai/message', [
        'query' => [
            'q' => $message,
        ],
        'headers' => [
            'Authorization' => 'Bearer ' . $witAiAccessToken,
        ],
    ]);

    $witData = json_decode($witResponse->getBody(), true);

    // Extract intent and entities from wit.ai response
    $intent = $witData['intents'][0]['name'] ?? null;
    $entities = $witData['entities'] ?? [];

    // Log intent and entities for debugging
    Log::info('Intent: ' . $intent);
    Log::info('Entities: ' . json_encode($entities));
    Log::info('Received Message: ' . $message);
    Log::info(json_encode($witData));

    // Handle intents based on wit.ai analysis
    if ($intent === 'greeting_intent') {
        // Greet the user and ask about their document request
        $greetResponses = [
            "Hello!, How may I help you regarding your document request?",
            "Greetings!, How can I assist you today?",
            "Hello! How can I assist you with your document request?",
            "Kamusta User!, Ano ang maililingkod ko ngayong araw?",
        ];
        $randomResponse = $greetResponses[array_rand($greetResponses)];
    
        $response = $randomResponse;
        return response()->json(['response' => $response]);
    } elseif ($intent === 'documentRequest_intent') {
        // Extract requested document type
        $requestedDocument = $entities['document_type'][0]['value'] ?? null;
    
        // Store the document type in the session for later use
        session(['document' => $requestedDocument]);
    
        // Send a special response to indicate the Flutter UI to show the full name input form
        $response = "Please enter your full name in the format: FirstName, MiddleName, LastName";
        return response()->json(['response' => $response, 'action' => 'show_full_name_form']);

    } elseif ($intent === 'help'){

        $helpResponses = [
            "Sure! To request a document from our barangay, type the name of the document you need (e.g., 'Barangay ID' or 'Birth Certificate').",
            "I'm here to assist you with your document request. The chatbot is designed for handling document requests. Just let me know which document you want.",
            "Need a document? No problem! Tell me the name of the document you're looking for, like 'Barangay Clearance' or 'Barangay ID'.",
            "Hello! Ready to request a document? Simply type the name of the document you require.",
            "Kailangan mo ng dokumento galing sa aming barangay?, I-type mo lang ang dokumento na katulad ng 'Barangay Clearance' o 'Barangay ID'.",
            "You need help? No problem!, Just tell me the name of the document you're looking for, like a 'Certificate of Indigency' or 'Barangay Clearance'",
        ];

        // Randomly select a response from the list
        $randomResponse = $helpResponses[array_rand($helpResponses)];

        // Assign the selected response to $response
        $response = $randomResponse;
        return response()->json(['response' => $response]);

    } elseif ($intent === 'hotline') {
        $response = "This is the hotlines provided in our barangay:
         *PHONE NUMBER AND CERTAIN INFORMATION IN CENTRAL BICUTAN REGARDING HOTLINES AND EMERGENCIES GOES HERE.";
        return response()->json(['response' => $response]);
    } elseif ($intent === 'other_intent') {
        
        $otherResponses = [
            "Sorry, I'm only designed for handling document requests for our barangay, You can go to our barangay regarding on your concern.",
            "My apologies, I'm only designed for handling document requests, if you have other concerns, please go to our Barangay Hall for more information.",
            "I'm sorry, the chatbot is only designed for handling document requests, You can go to our barangay if you have concerns.",
            "Patawad, Dinesenyo ako para maghawak ng request ng mga dokumento sa ating barangay, Pwede ka naman pumunta sa aming barangay sa mga ganyang impormasyon",
        ]; 

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);

        //if user intents are in Tagalog when asking about the system.
    } elseif ($intent === 'about_tagalog') {
        $otherResponses = [
            "Itong system na ito ay dinesenyo para mag-handle ng document request gamit ang chatbot para sa barangay Central Bicutan",
            "Nilikha itong sistemang ito para mag-hawak ng mga document request gamit ang chatbot para sa barangay Central Bicutan",
        ];

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);

    } elseif ($intent === 'about_tagalog_origin') {
        $otherResponses = [
            "Itong system na ito ay ginawa ng mga 4th year BSCS students para sa isang thesis sa Taguig City University, at dinesenyo ito para maghandle ng mga request ng mga dokumento para sa barangay Central Bicutan",
            "Ang sistemang ito ay ginawa para sa isang thesis ng isang groupo ng mga kolehiyong nagaaral ng Bachelor of Science in Computer Science sa Taguig City University",
        ];

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);

    } elseif ($intent === 'about_tagalog_dev') {
        $otherResponses = [
            "Itong system na ito ay ginawa lamang ng isang groupo ng mga estuyanteng nag-aaral ng Computer Science sa Taguig City University sa loob ng isang semester gamit ang Flutter SDK at Laravel framework.",

            "Ang sistemang ito ay ginawa gamit Flutter SDK at Laravel framework para sa isang thesis ng isang groupo ng mga kolehiyong nagaaral ng Bachelor of Science in Computer Science sa Taguig City University",
           
        ];

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);

    } elseif ($intent === 'about_tagalog_scope') {
        $otherResponses = [
            "Ang sakop lang ng sistemang ito ay nakapaloob lang base sa census ng barangay Central Bicutan",
            "Sakop lang ng sistemang ito ay nakapaloob lang base sa census ng barangay Central Bicutan",
        ];

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);
    } elseif ($intent === 'about_tagalog_benefit') {
        $otherResponses = [
            "Ang benefisyong makukuha dito sa aming sistema, na mas mapapadali at less hassle dahil di na sila pupunta sa barangay para mag request ng dokumento online",
        ];

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);

        //if user intents are in English (WILL BE TRAINED BY TOMORROW)
      } elseif ($intent === 'about') {
        $otherResponses = [
            "This system is designed to handle document requests through chatbot in Barangay Central Bicutan.",
             "This system is created to handle document requests through a chatbot in Barangay Central Bicutan.",
        ];

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);

    } elseif ($intent === 'about_origin') {
        $otherResponses = [
            "This system is created by a group of 4th year BSCS students as a thesis in Taguig City University, and designed to handle online document requests in barangay Central Bicutan",
            "This system was designed and created by a group of college students studying under Bachelor of Science in Computer Science in Taguig City University.",
        ];

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);

    } elseif ($intent === 'about_dev') {
        $otherResponses = [
            "This system was created in just one semester by a group of students studying Computer Science in Taguig City University using Flutter SDK and Laravel framework",
            "The system was created using Flutter SDK and Laravel framework as a thesis by a certain group of students studying Computer Science in Taguig City University",
        ];

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);

    } elseif ($intent === 'about_scope') {
        $otherResponses = [
            "The scope of this system is based from the census of Barangay Central Bicutan",
            "The scope of this system is based from the census of Barangay Central Bicutan, if your name is in the census of the barangay, you can request a document in the barangay online.",
        ];
        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);
    } elseif ($intent === 'about_benefit') {
        $otherResponses = [
          //  "Ang benefisyong makukuha dito sa aming sistema, na mas mapapadali at less hassle dahil di na sila pupunta sa barangay para mag request ng dokumento online",
            "The benefits you will get by using our system, it will be easier and less hassle as you will only go to our barangay to claim you desired document you've requested online.",
        ];

        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);

    } else {
        // Handle unrecognized intent here
        $otherResponses = [
            "I'm sorry, I couldn't understand your request.",
            "Patawad, Hindi ko po maintindihan ang iyong request",
            "My apologies, I can't understand your request",
        ];
        $randomResponse = $otherResponses[array_rand($otherResponses)];
        $response = $randomResponse;
        return response()->json(['response' => $response]);
    }
   // return response()->json(['response' => $response ?? '']);
}


public function searchCensus(Request $request)
{
    $this->validate($request, [
        'firstname' => 'required|string',
        'middlename' => 'required|string',
        'lastname' => 'required|string',
    ]);

    $firstName = $request->input('firstname');
    $middleName = $request->input('middlename');
    $lastName = $request->input('lastname');

    Log::info('Full Name: ' . $firstName . ', ' . $middleName . ',' . $lastName);

    $query = census::where('firstname', $firstName)
                    ->where('lastname', $lastName);

    if (!empty($middleName)) {
        $query->where('middlename', $middleName);
    }

    $user = $query->first();

    if ($user) {
        $response = "We found your name in our records! Please wait; a form will pop up on your screen, and you can fill out more of your details there.";
        return response()->json(['response' => $response, 'action' => 'show_information_form']);
    } else {

        $otherResponses = [
            "Sorry, we could not find your name in our records... Please try again.",
            "My apologies, the system could not find your name in our records... Maybe your name is not in our census yet.",
        ];
        $randomResponse = $otherResponses[array_rand($otherResponses)];
        return response()->json(['response' => $randomResponse]);
    }
}

    
}    