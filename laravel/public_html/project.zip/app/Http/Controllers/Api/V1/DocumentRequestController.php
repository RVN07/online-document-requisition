<?php

namespace App\Http\Controllers\Api\V1;

use App\filters\DocumentRequestFilter;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\UpdateDocumentRequestRequest;
use App\Http\Resources\V1\DocumentRequestCollection;
use App\Http\Resources\V1\DocumentRequestResource;
use App\Models\DocumentRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;




class DocumentRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $filter = new DocumentRequestFilter();
        $filterItem = $filter->transform($request);
    
        $documentRequests = DocumentRequest::when(count($filterItem) > 0, function ($query) use ($filterItem) {
            return $query->where($filterItem);
        })->get();
    
        // Transform the 'required' attribute to 'Yes' or 'No' based on the boolean value
        $documentRequests->transform(function ($documentRequest) {
            $documentRequest->required = $documentRequest->required ? 'Yes' : 'No';
            return $documentRequest;
        });
    
        return new DocumentRequestCollection($documentRequests);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
    $request->validate([
            // Your other validation rules
        'firstName' => 'required',
        'middleName' => 'required',
        'lastName' => 'required',
        'documenttype' => 'required',
        'required' => 'required',
        'email' => 'required',
        'contact' => 'required',
        'valid_id' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048', // Adjust image types and size limit as needed
        ]);

    // Handle image upload
        if ($request->hasFile('valid_id')) {
        $image = $request->file('valid_id');
        $imageName = time() . '.' . $image->getClientOriginalExtension();

        // Store the image in the 'uploads' directory within the storage folder
        $image->storeAs('uploads', $imageName, 'public');

        // Save the relative image path to the database
        $documentRequest = new DocumentRequest($request->all());
        $documentRequest->valid_id = 'uploads/' . $imageName;// Save the relative image path
        $documentRequest->save();

        return response()->json(['message' => 'Document request submitted successfully.']);
    } else {
        return response()->json(['message' => 'Image not found.'], 400);
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(DocumentRequest $documentRequest,$id)
    {
        $this->authorize('view', $documentRequest);
        $documentRequest = DocumentRequest::findOrFail($id);
        return new DocumentRequestResource($documentRequest);
    }
    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DocumentRequest $documentRequest)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDocumentRequestRequest $request, DocumentRequest $documentRequest)
    {
        $this->authorize('update', $documentRequest); // Authorize based on the specific $census record
        $validated = $request->validated();
    
        $documentRequest->update($validated);
        return new DocumentRequestResource($documentRequest);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        try {
            // Find the document request by its ID
            $documentRequest = DocumentRequest::find($id);
    
            // Check if the document request exists
            if (!$documentRequest) {
                return response()->json(['message' => 'Document request not found.'], 404);
            }
    
            // Get the image path from the 'valid_id' column
            $imagePath = 'public/' . $documentRequest->valid_id;
    
            // Delete the file using the Storage facade
            if (Storage::disk('local')->exists($imagePath)) {
                Storage::disk('local')->delete($imagePath);
            }
    
            // Delete the row from the database
            $documentRequest->delete();
    
            return response()->json(['message' => 'Document request deleted successfully, along with its associated image.']);
        } catch (\Exception $e) {
            // Handle the exception and return an error response
            return response()->json(['error' => 'An error occurred while deleting the document request.'], 500);
        }
    }
    
    

public function serveImage($filename)
{
    $path = storage_path('app/public/uploads/' . $filename);

    if (file_exists($path)) {
        // Return the image as a response
        return response()->file($path);
    }

    // Handle the case where the image file doesn't exist
    return response()->json(['error' => 'Image not found'], 404);
}


public function approve(Request $request, $id)
{
    $documentRequest = DocumentRequest::findOrFail($id);
    $this->authorize('update', $documentRequest); 
    $claimDateFromRequest = $request->input('claim_date');
    // Get the receiver's email from the document_requests table
    $to = $documentRequest->email;

    if (!empty($to)) {
        $subject = 'Document Request Approved';
        $message = 'Your document request of ' . $documentRequest->documenttype . ' has been approved.' . 'You will claim your document in this date ' . $claimDateFromRequest;

        $headers = 'From: your_email@example.com';

        // Use PHP's mail function to send the email
        if (mail($to, $subject, $message, $headers)) {
            // Update the status to 'approved' and set the claim_date
            $documentRequest->update([
                'status' => 'approved',
                'claim_date' => $claimDateFromRequest, // Update claim_date from the request
            ]);

            Log::info('claim_date after update: ' . $documentRequest->claim_date);

            return response()->json(['message' => 'Document request approved successfully. Email sent.']);
        } else {
            // Handle the case where the email couldn't be sent
            return response()->json(['message' => 'Document request approved successfully, but email sending failed.'], 500);
        }
    } else {
        // Handle the case where the email is empty in the document_requests table
        return response()->json(['message' => 'Document request approved successfully, but recipient email is missing.']);
    }
}

public function claim(Request $request, $id)
{
    $documentRequest = DocumentRequest::findOrFail($id);
    $this->authorize('update', $documentRequest);

    $documentRequest->update([
        'status' => 'claimed',
        //'claim_date' => $claimDateFromRequest, // Update claim_date from the request
    ]);
}

public function reject(Request $request, $id)
{
    $documentRequest = DocumentRequest::findOrFail($id);
    $this->authorize('update', $documentRequest); 
    // Get the receiver's email from the document_requests table
    $to = $documentRequest->email;

    if (!empty($to)) {
        $subject = 'Document Request Rejected';
        $message = 'Your document request has been rejected.';
        $headers = 'From: your_email@example.com';

        // Use PHP's mail function to send the email
        if (mail($to, $subject, $message, $headers)) {
            // Update the status to 'rejected'
            $documentRequest->update(['status' => 'rejected']);

            return response()->json(['message' => 'Document request rejected successfully. Email sent.']);
        } else {
            // Handle the case where the email couldn't be sent
            return response()->json(['message' => 'Document request rejected successfully, but email sending failed.'], 500);
        }
    } else {
        // Handle the case where the email is empty in the document_requests table
        return response()->json(['message' => 'Document request rejected successfully, but recipient email is missing.']);
    }
}

}

