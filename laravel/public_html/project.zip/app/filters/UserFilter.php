<?php

namespace App\Filters;

use App\Filters\ApiFilter;
use Illuminate\Http\Request;

class UserFilter extends ApiFilter {
    protected $safeParams = [
        'role_id' => ['eq'],
        'firstname' => ['eq'],
        'middlename' => ['eq'],
        'lastname' => ['eq'],
        'address' => ['eq'],
        'age' => ['eq', 'gt', 'gte', 'lt', 'lte'],
        'birthDate' => ['eq', 'gt', 'gte', 'lt', 'lte'],
        'contactnumber' => ['eq'],
        'email' => ['eq'],
        'username' => ['eq'],
        'password' => ['eq'],
    ];

    protected $columnMap = [
        
    ];

    protected $operatorMap = [
        'eq' => '=',
        'lt' => '<',
        'lte' => '<=',
        'gt' => '>',
        'gte' => '>='
    ];
}