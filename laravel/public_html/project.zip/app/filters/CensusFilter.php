<?php

namespace App\filters;

use App\filters\ApiFilter;
use Illuminate\Http\Request;

class CensusFilter extends ApiFilter{
    protected $safeParams = [
        'role_id' => ['eq'],
            'firstname' => ['eq'],
            'middlename' => ['eq'],
            'lastname' => ['eq'],
            'gender' => ['eq'],
            'address'=> ['eq'],
            'age' => ['eq', 'gt', 'gte', 'lt', 'lte'],
            'birthdate' => ['eq', 'gt', 'gte', 'lt', 'lte'],
            'contactNumber' => ['eq'],
    ];
    protected $columnMap = [  
    ];
    protected $operatorMap = [
        'eq' => '=',
        'lt' => '<',
        'lte' => '<=',
        'gt' => '>',
        'gte' => '>='
    ];
}