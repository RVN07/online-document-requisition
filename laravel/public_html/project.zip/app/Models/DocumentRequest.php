<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'id',
        'firstName',
        'middleName',
        'lastName',
        'documenttype',
        'required',
        'email',
        'contact',
        'valid_id',
        'status',
        'submitted_time',
        'claim_date',
    ];

    public function getRequiredAttribute($value)
    {
        return $value ? 'Yes' : 'No';
    }

    protected $casts = [
        'valid_id' => 'array',
    ];

}
