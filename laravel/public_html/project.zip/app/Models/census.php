<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class census extends Model
{
    use HasFactory;

    protected $fillable = [
        'role_id',
        'firstname',
        'middlename',
        'lastname',
        'gender',
        'address',
        'age',
        'birthdate',
        'contactNumber',
    ];
}
