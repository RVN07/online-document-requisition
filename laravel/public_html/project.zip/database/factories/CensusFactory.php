<?php

namespace Database\Factories;

use App\Models\Role;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\census>
 */
class CensusFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {

        $gender = [
            'Male',
            'Female',
            // Add more documents if needed
        ];
        return [
            'role_id' => Role::where('name', 'Resident')->firstOrFail()->id,
            'firstname' => $this->faker->firstName,
            'middlename' => $this->faker->firstName,
            'lastname' => $this->faker->lastName,
            'gender' => $this->faker->randomElement($gender),
            'address'=> $this->faker->address,
            'age' => $this->faker->numberBetween($min = 10, $max = 60),
            'birthdate' => $this->faker->date,
            'contactNumber' => $this->faker->phoneNumber,
            
        ];
    }
}
