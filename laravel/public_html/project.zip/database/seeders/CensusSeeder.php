<?php

namespace Database\Seeders;

use App\Models\census;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CensusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        census::factory()
            ->count(50)
            ->create();
    }
}
