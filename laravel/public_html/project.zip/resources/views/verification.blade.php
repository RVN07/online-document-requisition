<!DOCTYPE html>
<html>
<head>
    <title>Email Verification</title>
</head>
<body>
    <p>Thank you for registering. Your verification code is:</p>
    <p><strong>{{ $verificationCode }}</strong></p>
</body>
</html>
