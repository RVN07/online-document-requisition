<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Request Approved</title>
</head>
<body>
    <p>Hello,</p>
    
    <p>We are pleased to inform you that your document request has been approved.</p>
    
    <p>Your requested document is: <strong><?php echo e($documenttype); ?></strong></p>
    
    <p>Thank you for using our service.</p>
</body>
</html>
<?php /**PATH C:\Users\Administrator\Documents\programming\laravel\project\resources\views/emails/document_request_approved_notif.blade.php ENDPATH**/ ?>